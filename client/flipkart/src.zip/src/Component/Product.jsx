import React, { useState } from 'react'
import axios from 'axios';
import { createClient } from '@supabase/supabase-js'
const supabaseUrl = 'https://gjbteqzcgvndznnfdhbk.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdqYnRlcXpjZ3ZuZHpubmZkaGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjI3NzQ1ODIsImV4cCI6MjAzODM1MDU4Mn0.XaLKP0kS6R8Pg2HhwYtLuFRhlfeQ7lhhWFpkX1PsdoM'
const supabase = createClient(supabaseUrl, supabaseKey)
const Product = () => {


    let [input,setInput]=useState({
        name:"",
        brand: "",
        price:"",
        category:"",
        description:"",
        image:""
    })
    function fun1(e) {
        const { name, value } = e.target;
    
        setInput({ ...input, [name]: value })
        // console.log(input);
    
      }
      function handleImageChange(e) {
        const dataimg=new FileReader()
        dataimg.addEventListener('load',()=>{
          setInput({ ...input, image:dataimg.result})
        })
        dataimg.readAsDataURL(e.target.files[0])
      

    }
    const done=(e)=>{
      e.preventDefault();
        console.log(input);

    }
  return (
    <>   

     <div>
        <form onSubmit={done} >
            <input type="text" name="name"   onInput={fun1} value={input.name}placeholder='name' id="" /><br />
            <input type="text" name="brand"  onInput={fun1} value={input.brand} placeholder='brand 'id="" /><br />
            <input type="number" name="price"  onInput={fun1} value={input.price} placeholder='price 'id="" /><br />
            <input type="text" name="description"   onInput={fun1} value={input.description} placeholder='description' id="" /><br />
            <input type="text" name="category"   onInput={fun1} value={input.category} placeholder='category' id="" /><br />
            <input type="file" name="image"   onChange={handleImageChange}  placeholder='image' id="" />
            <br />
            <input type='submit' />


        </form>

<img src={input.image} height={200}/>
     </div>

</>

  )
}

export default Product