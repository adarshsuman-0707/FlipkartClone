import React from 'react'
import {Route,Routes} from 'react-router-dom'
import App from './App'
import Header from './Component/Header'
 const Routing = () => {
  return (
  <>
  <Header/>

  
  
  </>
  )}

export default Routing